
DROP INDEX idx_stage_results_player_id;
DROP INDEX idx_stage_results_stage_id;
DROP INDEX idx_stages_tournament_id;
DROP INDEX idx_players_pix_key;
DROP INDEX idx_players_unique_identifier;
DROP TABLE stage_results;
DROP TABLE stages;
DROP TABLE tournaments;
DROP TABLE players;
