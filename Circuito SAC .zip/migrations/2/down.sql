
ALTER TABLE tournaments DROP COLUMN year;
